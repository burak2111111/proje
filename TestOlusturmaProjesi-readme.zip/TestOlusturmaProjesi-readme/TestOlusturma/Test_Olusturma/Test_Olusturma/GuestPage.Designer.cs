﻿namespace Test_Olusturma
{
    partial class GuestPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_soru1 = new System.Windows.Forms.Label();
            this.lb_soru2 = new System.Windows.Forms.Label();
            this.lb_soru4 = new System.Windows.Forms.Label();
            this.lb_soru5 = new System.Windows.Forms.Label();
            this.lb_soru6 = new System.Windows.Forms.Label();
            this.lb_soru7 = new System.Windows.Forms.Label();
            this.lb_soru8 = new System.Windows.Forms.Label();
            this.lb_soru9 = new System.Windows.Forms.Label();
            this.lb_soru10 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.lb_soru3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_soru1
            // 
            this.lb_soru1.AutoSize = true;
            this.lb_soru1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru1.Location = new System.Drawing.Point(30, 22);
            this.lb_soru1.Name = "lb_soru1";
            this.lb_soru1.Size = new System.Drawing.Size(76, 25);
            this.lb_soru1.TabIndex = 0;
            this.lb_soru1.Text = "Soru 1:";
            // 
            // lb_soru2
            // 
            this.lb_soru2.AutoSize = true;
            this.lb_soru2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru2.Location = new System.Drawing.Point(30, 96);
            this.lb_soru2.Name = "lb_soru2";
            this.lb_soru2.Size = new System.Drawing.Size(76, 25);
            this.lb_soru2.TabIndex = 1;
            this.lb_soru2.Text = "Soru 2:";
            // 
            // lb_soru4
            // 
            this.lb_soru4.AutoSize = true;
            this.lb_soru4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru4.Location = new System.Drawing.Point(30, 246);
            this.lb_soru4.Name = "lb_soru4";
            this.lb_soru4.Size = new System.Drawing.Size(76, 25);
            this.lb_soru4.TabIndex = 3;
            this.lb_soru4.Text = "Soru 4:";
            // 
            // lb_soru5
            // 
            this.lb_soru5.AutoSize = true;
            this.lb_soru5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru5.Location = new System.Drawing.Point(30, 332);
            this.lb_soru5.Name = "lb_soru5";
            this.lb_soru5.Size = new System.Drawing.Size(76, 25);
            this.lb_soru5.TabIndex = 4;
            this.lb_soru5.Text = "Soru 5:";
            // 
            // lb_soru6
            // 
            this.lb_soru6.AutoSize = true;
            this.lb_soru6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru6.Location = new System.Drawing.Point(30, 421);
            this.lb_soru6.Name = "lb_soru6";
            this.lb_soru6.Size = new System.Drawing.Size(76, 25);
            this.lb_soru6.TabIndex = 5;
            this.lb_soru6.Text = "Soru 6:";
            // 
            // lb_soru7
            // 
            this.lb_soru7.AutoSize = true;
            this.lb_soru7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru7.Location = new System.Drawing.Point(30, 511);
            this.lb_soru7.Name = "lb_soru7";
            this.lb_soru7.Size = new System.Drawing.Size(76, 25);
            this.lb_soru7.TabIndex = 6;
            this.lb_soru7.Text = "Soru 7:";
            // 
            // lb_soru8
            // 
            this.lb_soru8.AutoSize = true;
            this.lb_soru8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru8.Location = new System.Drawing.Point(30, 603);
            this.lb_soru8.Name = "lb_soru8";
            this.lb_soru8.Size = new System.Drawing.Size(76, 25);
            this.lb_soru8.TabIndex = 7;
            this.lb_soru8.Text = "Soru 8:";
            // 
            // lb_soru9
            // 
            this.lb_soru9.AutoSize = true;
            this.lb_soru9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru9.Location = new System.Drawing.Point(30, 700);
            this.lb_soru9.Name = "lb_soru9";
            this.lb_soru9.Size = new System.Drawing.Size(76, 25);
            this.lb_soru9.TabIndex = 8;
            this.lb_soru9.Text = "Soru 9:";
            // 
            // lb_soru10
            // 
            this.lb_soru10.AutoSize = true;
            this.lb_soru10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru10.Location = new System.Drawing.Point(30, 799);
            this.lb_soru10.Name = "lb_soru10";
            this.lb_soru10.Size = new System.Drawing.Size(87, 25);
            this.lb_soru10.TabIndex = 9;
            this.lb_soru10.Text = "Soru 10:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(23, 13);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 50;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(179, 13);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 17);
            this.radioButton2.TabIndex = 51;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(372, 13);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(85, 17);
            this.radioButton3.TabIndex = 52;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(542, 13);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(85, 17);
            this.radioButton4.TabIndex = 53;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // lb_soru3
            // 
            this.lb_soru3.AutoSize = true;
            this.lb_soru3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_soru3.Location = new System.Drawing.Point(30, 171);
            this.lb_soru3.Name = "lb_soru3";
            this.lb_soru3.Size = new System.Drawing.Size(76, 25);
            this.lb_soru3.TabIndex = 2;
            this.lb_soru3.Text = "Soru 3:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton4);
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.radioButton2);
            this.panel1.Controls.Add(this.radioButton3);
            this.panel1.Location = new System.Drawing.Point(12, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 43);
            this.panel1.TabIndex = 90;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton5);
            this.panel2.Controls.Add(this.radioButton6);
            this.panel2.Controls.Add(this.radioButton7);
            this.panel2.Controls.Add(this.radioButton8);
            this.panel2.Location = new System.Drawing.Point(12, 125);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(700, 43);
            this.panel2.TabIndex = 91;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(542, 13);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(85, 17);
            this.radioButton5.TabIndex = 53;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "radioButton5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(23, 13);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(85, 17);
            this.radioButton6.TabIndex = 50;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "radioButton6";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(179, 13);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(85, 17);
            this.radioButton7.TabIndex = 51;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "radioButton7";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(372, 13);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(85, 17);
            this.radioButton8.TabIndex = 52;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "radioButton8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButton9);
            this.panel3.Controls.Add(this.radioButton10);
            this.panel3.Controls.Add(this.radioButton11);
            this.panel3.Controls.Add(this.radioButton12);
            this.panel3.Location = new System.Drawing.Point(12, 200);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(700, 43);
            this.panel3.TabIndex = 91;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(542, 13);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(85, 17);
            this.radioButton9.TabIndex = 53;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "radioButton9";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(23, 13);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(91, 17);
            this.radioButton10.TabIndex = 50;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "radioButton10";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(179, 13);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(91, 17);
            this.radioButton11.TabIndex = 51;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "radioButton11";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(372, 13);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(91, 17);
            this.radioButton12.TabIndex = 52;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "radioButton12";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButton13);
            this.panel4.Controls.Add(this.radioButton14);
            this.panel4.Controls.Add(this.radioButton15);
            this.panel4.Controls.Add(this.radioButton16);
            this.panel4.Location = new System.Drawing.Point(12, 274);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(700, 43);
            this.panel4.TabIndex = 91;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(542, 13);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(91, 17);
            this.radioButton13.TabIndex = 53;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "radioButton13";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(23, 13);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(91, 17);
            this.radioButton14.TabIndex = 50;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "radioButton14";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(179, 13);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(91, 17);
            this.radioButton15.TabIndex = 51;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "radioButton15";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(372, 13);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(91, 17);
            this.radioButton16.TabIndex = 52;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "radioButton16";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButton17);
            this.panel5.Controls.Add(this.radioButton18);
            this.panel5.Controls.Add(this.radioButton19);
            this.panel5.Controls.Add(this.radioButton20);
            this.panel5.Location = new System.Drawing.Point(12, 360);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(700, 43);
            this.panel5.TabIndex = 92;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(542, 13);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(91, 17);
            this.radioButton17.TabIndex = 53;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "radioButton17";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(23, 13);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(91, 17);
            this.radioButton18.TabIndex = 50;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "radioButton18";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(179, 13);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(91, 17);
            this.radioButton19.TabIndex = 51;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "radioButton19";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(372, 13);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(91, 17);
            this.radioButton20.TabIndex = 52;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "radioButton20";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton21);
            this.panel6.Controls.Add(this.radioButton22);
            this.panel6.Controls.Add(this.radioButton23);
            this.panel6.Controls.Add(this.radioButton24);
            this.panel6.Location = new System.Drawing.Point(12, 449);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(700, 43);
            this.panel6.TabIndex = 93;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(542, 13);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(91, 17);
            this.radioButton21.TabIndex = 53;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "radioButton21";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(23, 13);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(91, 17);
            this.radioButton22.TabIndex = 50;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "radioButton22";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(179, 13);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(91, 17);
            this.radioButton23.TabIndex = 51;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "radioButton23";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(372, 13);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(91, 17);
            this.radioButton24.TabIndex = 52;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "radioButton24";
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.radioButton25);
            this.panel7.Controls.Add(this.radioButton26);
            this.panel7.Controls.Add(this.radioButton27);
            this.panel7.Controls.Add(this.radioButton28);
            this.panel7.Location = new System.Drawing.Point(12, 548);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(700, 43);
            this.panel7.TabIndex = 94;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(542, 13);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(91, 17);
            this.radioButton25.TabIndex = 53;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "radioButton25";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(23, 13);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(91, 17);
            this.radioButton26.TabIndex = 50;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "radioButton26";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(179, 13);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(91, 17);
            this.radioButton27.TabIndex = 51;
            this.radioButton27.TabStop = true;
            this.radioButton27.Text = "radioButton27";
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(372, 13);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(91, 17);
            this.radioButton28.TabIndex = 52;
            this.radioButton28.TabStop = true;
            this.radioButton28.Text = "radioButton28";
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.radioButton29);
            this.panel8.Controls.Add(this.radioButton30);
            this.panel8.Controls.Add(this.radioButton31);
            this.panel8.Controls.Add(this.radioButton32);
            this.panel8.Location = new System.Drawing.Point(12, 642);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(700, 43);
            this.panel8.TabIndex = 91;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Location = new System.Drawing.Point(542, 13);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(91, 17);
            this.radioButton29.TabIndex = 53;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "radioButton29";
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(23, 13);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(91, 17);
            this.radioButton30.TabIndex = 50;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "radioButton30";
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(179, 13);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(91, 17);
            this.radioButton31.TabIndex = 51;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "radioButton31";
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(372, 13);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(91, 17);
            this.radioButton32.TabIndex = 52;
            this.radioButton32.TabStop = true;
            this.radioButton32.Text = "radioButton32";
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.radioButton33);
            this.panel9.Controls.Add(this.radioButton34);
            this.panel9.Controls.Add(this.radioButton35);
            this.panel9.Controls.Add(this.radioButton36);
            this.panel9.Location = new System.Drawing.Point(12, 740);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(700, 43);
            this.panel9.TabIndex = 91;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(542, 13);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(91, 17);
            this.radioButton33.TabIndex = 53;
            this.radioButton33.TabStop = true;
            this.radioButton33.Text = "radioButton33";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(23, 13);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(91, 17);
            this.radioButton34.TabIndex = 50;
            this.radioButton34.TabStop = true;
            this.radioButton34.Text = "radioButton34";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(179, 13);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(91, 17);
            this.radioButton35.TabIndex = 51;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "radioButton35";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(372, 13);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(91, 17);
            this.radioButton36.TabIndex = 52;
            this.radioButton36.TabStop = true;
            this.radioButton36.Text = "radioButton36";
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.radioButton37);
            this.panel10.Controls.Add(this.radioButton38);
            this.panel10.Controls.Add(this.radioButton39);
            this.panel10.Controls.Add(this.radioButton40);
            this.panel10.Location = new System.Drawing.Point(12, 827);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(700, 43);
            this.panel10.TabIndex = 91;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(542, 13);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(91, 17);
            this.radioButton37.TabIndex = 53;
            this.radioButton37.TabStop = true;
            this.radioButton37.Text = "radioButton37";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(23, 13);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(91, 17);
            this.radioButton38.TabIndex = 50;
            this.radioButton38.TabStop = true;
            this.radioButton38.Text = "radioButton38";
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(179, 13);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(91, 17);
            this.radioButton39.TabIndex = 51;
            this.radioButton39.TabStop = true;
            this.radioButton39.Text = "radioButton39";
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(372, 13);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(91, 17);
            this.radioButton40.TabIndex = 52;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "radioButton40";
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // GuestPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 914);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lb_soru10);
            this.Controls.Add(this.lb_soru9);
            this.Controls.Add(this.lb_soru8);
            this.Controls.Add(this.lb_soru7);
            this.Controls.Add(this.lb_soru6);
            this.Controls.Add(this.lb_soru5);
            this.Controls.Add(this.lb_soru4);
            this.Controls.Add(this.lb_soru3);
            this.Controls.Add(this.lb_soru2);
            this.Controls.Add(this.lb_soru1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "GuestPage";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GuestPage";
            this.Load += new System.EventHandler(this.GuestPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_soru1;
        private System.Windows.Forms.Label lb_soru2;
        private System.Windows.Forms.Label lb_soru4;
        private System.Windows.Forms.Label lb_soru5;
        private System.Windows.Forms.Label lb_soru6;
        private System.Windows.Forms.Label lb_soru7;
        private System.Windows.Forms.Label lb_soru8;
        private System.Windows.Forms.Label lb_soru9;
        private System.Windows.Forms.Label lb_soru10;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label lb_soru3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton40;
    }
}