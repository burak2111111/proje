﻿namespace Test_Olusturma
{
    partial class AdminAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("");
            this.lb_Soru = new System.Windows.Forms.Label();
            this.lb_aCevabi = new System.Windows.Forms.Label();
            this.lb_bCevabi = new System.Windows.Forms.Label();
            this.lb_cCevabi = new System.Windows.Forms.Label();
            this.lb_dCevabi = new System.Windows.Forms.Label();
            this.gb_SoruGuncellemePaneli = new System.Windows.Forms.GroupBox();
            this.txt_dCevabi = new System.Windows.Forms.TextBox();
            this.txt_cCevabi = new System.Windows.Forms.TextBox();
            this.txt_bCevabi = new System.Windows.Forms.TextBox();
            this.txt_aCevabi = new System.Windows.Forms.TextBox();
            this.txt_Soru = new System.Windows.Forms.TextBox();
            this.bt_SoruGuncelle = new System.Windows.Forms.Button();
            this.bt_SoruSil = new System.Windows.Forms.Button();
            this.bt_SoruEkle = new System.Windows.Forms.Button();
            this.bt_SoruListesiniGuncelle = new System.Windows.Forms.Button();
            this.lb_Sorular = new System.Windows.Forms.Label();
            this.lb_Cevaplar = new System.Windows.Forms.Label();
            this.lv_Sorular = new System.Windows.Forms.ListView();
            this.soruNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.soru = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_Cevaplar = new System.Windows.Forms.ListView();
            this.sorNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.aCevabi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bCevabi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cCevabi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dCevabi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gb_SoruGuncellemePaneli.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_Soru
            // 
            this.lb_Soru.AutoSize = true;
            this.lb_Soru.Location = new System.Drawing.Point(24, 43);
            this.lb_Soru.Name = "lb_Soru";
            this.lb_Soru.Size = new System.Drawing.Size(47, 20);
            this.lb_Soru.TabIndex = 0;
            this.lb_Soru.Text = "Soru:";
            // 
            // lb_aCevabi
            // 
            this.lb_aCevabi.AutoSize = true;
            this.lb_aCevabi.Location = new System.Drawing.Point(24, 87);
            this.lb_aCevabi.Name = "lb_aCevabi";
            this.lb_aCevabi.Size = new System.Drawing.Size(76, 20);
            this.lb_aCevabi.TabIndex = 1;
            this.lb_aCevabi.Text = "A Cevabı:";
            // 
            // lb_bCevabi
            // 
            this.lb_bCevabi.AutoSize = true;
            this.lb_bCevabi.Location = new System.Drawing.Point(24, 136);
            this.lb_bCevabi.Name = "lb_bCevabi";
            this.lb_bCevabi.Size = new System.Drawing.Size(76, 20);
            this.lb_bCevabi.TabIndex = 2;
            this.lb_bCevabi.Text = "B Cevabı:";
            // 
            // lb_cCevabi
            // 
            this.lb_cCevabi.AutoSize = true;
            this.lb_cCevabi.Location = new System.Drawing.Point(24, 183);
            this.lb_cCevabi.Name = "lb_cCevabi";
            this.lb_cCevabi.Size = new System.Drawing.Size(76, 20);
            this.lb_cCevabi.TabIndex = 3;
            this.lb_cCevabi.Text = "C Cevabı:";
            // 
            // lb_dCevabi
            // 
            this.lb_dCevabi.AutoSize = true;
            this.lb_dCevabi.Location = new System.Drawing.Point(24, 227);
            this.lb_dCevabi.Name = "lb_dCevabi";
            this.lb_dCevabi.Size = new System.Drawing.Size(77, 20);
            this.lb_dCevabi.TabIndex = 4;
            this.lb_dCevabi.Text = "D Cevabı:";
            // 
            // gb_SoruGuncellemePaneli
            // 
            this.gb_SoruGuncellemePaneli.Controls.Add(this.txt_dCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.txt_cCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.txt_bCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.txt_aCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.txt_Soru);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.bt_SoruGuncelle);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.bt_SoruSil);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.bt_SoruEkle);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.lb_Soru);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.lb_dCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.lb_aCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.lb_cCevabi);
            this.gb_SoruGuncellemePaneli.Controls.Add(this.lb_bCevabi);
            this.gb_SoruGuncellemePaneli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gb_SoruGuncellemePaneli.Location = new System.Drawing.Point(25, 21);
            this.gb_SoruGuncellemePaneli.Name = "gb_SoruGuncellemePaneli";
            this.gb_SoruGuncellemePaneli.Size = new System.Drawing.Size(270, 454);
            this.gb_SoruGuncellemePaneli.TabIndex = 5;
            this.gb_SoruGuncellemePaneli.TabStop = false;
            this.gb_SoruGuncellemePaneli.Text = "Soru Güncelleme Paneli";
            // 
            // txt_dCevabi
            // 
            this.txt_dCevabi.Location = new System.Drawing.Point(136, 227);
            this.txt_dCevabi.Name = "txt_dCevabi";
            this.txt_dCevabi.Size = new System.Drawing.Size(100, 26);
            this.txt_dCevabi.TabIndex = 12;
            // 
            // txt_cCevabi
            // 
            this.txt_cCevabi.Location = new System.Drawing.Point(136, 183);
            this.txt_cCevabi.Name = "txt_cCevabi";
            this.txt_cCevabi.Size = new System.Drawing.Size(100, 26);
            this.txt_cCevabi.TabIndex = 11;
            // 
            // txt_bCevabi
            // 
            this.txt_bCevabi.Location = new System.Drawing.Point(136, 136);
            this.txt_bCevabi.Name = "txt_bCevabi";
            this.txt_bCevabi.Size = new System.Drawing.Size(100, 26);
            this.txt_bCevabi.TabIndex = 10;
            // 
            // txt_aCevabi
            // 
            this.txt_aCevabi.Location = new System.Drawing.Point(136, 87);
            this.txt_aCevabi.Name = "txt_aCevabi";
            this.txt_aCevabi.Size = new System.Drawing.Size(100, 26);
            this.txt_aCevabi.TabIndex = 9;
            // 
            // txt_Soru
            // 
            this.txt_Soru.Location = new System.Drawing.Point(136, 43);
            this.txt_Soru.Name = "txt_Soru";
            this.txt_Soru.Size = new System.Drawing.Size(100, 26);
            this.txt_Soru.TabIndex = 8;
            // 
            // bt_SoruGuncelle
            // 
            this.bt_SoruGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bt_SoruGuncelle.Location = new System.Drawing.Point(61, 373);
            this.bt_SoruGuncelle.Name = "bt_SoruGuncelle";
            this.bt_SoruGuncelle.Size = new System.Drawing.Size(144, 40);
            this.bt_SoruGuncelle.TabIndex = 7;
            this.bt_SoruGuncelle.Text = "Soru Güncelle";
            this.bt_SoruGuncelle.UseVisualStyleBackColor = true;
            this.bt_SoruGuncelle.Click += new System.EventHandler(this.bt_SoruGuncelle_Click);
            // 
            // bt_SoruSil
            // 
            this.bt_SoruSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bt_SoruSil.Location = new System.Drawing.Point(153, 303);
            this.bt_SoruSil.Name = "bt_SoruSil";
            this.bt_SoruSil.Size = new System.Drawing.Size(111, 40);
            this.bt_SoruSil.TabIndex = 6;
            this.bt_SoruSil.Text = "Soru Sil";
            this.bt_SoruSil.UseVisualStyleBackColor = true;
            this.bt_SoruSil.Click += new System.EventHandler(this.bt_SoruSil_Click);
            // 
            // bt_SoruEkle
            // 
            this.bt_SoruEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bt_SoruEkle.Location = new System.Drawing.Point(6, 303);
            this.bt_SoruEkle.Name = "bt_SoruEkle";
            this.bt_SoruEkle.Size = new System.Drawing.Size(111, 40);
            this.bt_SoruEkle.TabIndex = 5;
            this.bt_SoruEkle.Text = "Soru Ekle";
            this.bt_SoruEkle.UseVisualStyleBackColor = true;
            this.bt_SoruEkle.Click += new System.EventHandler(this.bt_SoruEkle_Click);
            // 
            // bt_SoruListesiniGuncelle
            // 
            this.bt_SoruListesiniGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bt_SoruListesiniGuncelle.Location = new System.Drawing.Point(492, 422);
            this.bt_SoruListesiniGuncelle.Name = "bt_SoruListesiniGuncelle";
            this.bt_SoruListesiniGuncelle.Size = new System.Drawing.Size(226, 53);
            this.bt_SoruListesiniGuncelle.TabIndex = 8;
            this.bt_SoruListesiniGuncelle.Text = "Soru Listesini Güncelle";
            this.bt_SoruListesiniGuncelle.UseVisualStyleBackColor = true;
            this.bt_SoruListesiniGuncelle.Click += new System.EventHandler(this.bt_SoruListesiniGuncelle_Click);
            // 
            // lb_Sorular
            // 
            this.lb_Sorular.AutoSize = true;
            this.lb_Sorular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_Sorular.Location = new System.Drawing.Point(392, 21);
            this.lb_Sorular.Name = "lb_Sorular";
            this.lb_Sorular.Size = new System.Drawing.Size(114, 25);
            this.lb_Sorular.TabIndex = 9;
            this.lb_Sorular.Text = "SORULAR";
            // 
            // lb_Cevaplar
            // 
            this.lb_Cevaplar.AutoSize = true;
            this.lb_Cevaplar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_Cevaplar.Location = new System.Drawing.Point(392, 221);
            this.lb_Cevaplar.Name = "lb_Cevaplar";
            this.lb_Cevaplar.Size = new System.Drawing.Size(127, 25);
            this.lb_Cevaplar.TabIndex = 10;
            this.lb_Cevaplar.Text = "CEVAPLAR";
            // 
            // lv_Sorular
            // 
            this.lv_Sorular.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.soruNum,
            this.soru});
            this.lv_Sorular.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lv_Sorular.FullRowSelect = true;
            this.lv_Sorular.GridLines = true;
            this.lv_Sorular.HideSelection = false;
            this.lv_Sorular.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem4});
            this.lv_Sorular.Location = new System.Drawing.Point(397, 49);
            this.lv_Sorular.Name = "lv_Sorular";
            this.lv_Sorular.Size = new System.Drawing.Size(445, 169);
            this.lv_Sorular.TabIndex = 11;
            this.lv_Sorular.UseCompatibleStateImageBehavior = false;
            this.lv_Sorular.SelectedIndexChanged += new System.EventHandler(this.lv_Sorular_SelectedIndexChanged);
            // 
            // soruNum
            // 
            this.soruNum.Text = "Soru Numarası";
            this.soruNum.Width = 120;
            // 
            // soru
            // 
            this.soru.Text = "Soru";
            this.soru.Width = 316;
            // 
            // lv_Cevaplar
            // 
            this.lv_Cevaplar.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.sorNum,
            this.aCevabi,
            this.bCevabi,
            this.cCevabi,
            this.dCevabi});
            this.lv_Cevaplar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lv_Cevaplar.FullRowSelect = true;
            this.lv_Cevaplar.GridLines = true;
            this.lv_Cevaplar.HideSelection = false;
            this.lv_Cevaplar.Location = new System.Drawing.Point(397, 249);
            this.lv_Cevaplar.Name = "lv_Cevaplar";
            this.lv_Cevaplar.Size = new System.Drawing.Size(445, 162);
            this.lv_Cevaplar.TabIndex = 12;
            this.lv_Cevaplar.UseCompatibleStateImageBehavior = false;
            // 
            // sorNum
            // 
            this.sorNum.Text = "Soru Numarası";
            this.sorNum.Width = 120;
            // 
            // aCevabi
            // 
            this.aCevabi.Text = "A Cevabı";
            this.aCevabi.Width = 80;
            // 
            // bCevabi
            // 
            this.bCevabi.Text = "B Cevabı";
            this.bCevabi.Width = 80;
            // 
            // cCevabi
            // 
            this.cCevabi.Text = "C Cevabı";
            this.cCevabi.Width = 80;
            // 
            // dCevabi
            // 
            this.dCevabi.Text = "D Cevabı";
            this.dCevabi.Width = 80;
            // 
            // AdminAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 500);
            this.Controls.Add(this.lv_Cevaplar);
            this.Controls.Add(this.lv_Sorular);
            this.Controls.Add(this.lb_Cevaplar);
            this.Controls.Add(this.lb_Sorular);
            this.Controls.Add(this.bt_SoruListesiniGuncelle);
            this.Controls.Add(this.gb_SoruGuncellemePaneli);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "AdminAdd";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminAdd";
            this.Load += new System.EventHandler(this.AdminAdd_Load);
            this.gb_SoruGuncellemePaneli.ResumeLayout(false);
            this.gb_SoruGuncellemePaneli.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Soru;
        private System.Windows.Forms.Label lb_aCevabi;
        private System.Windows.Forms.Label lb_bCevabi;
        private System.Windows.Forms.Label lb_cCevabi;
        private System.Windows.Forms.Label lb_dCevabi;
        private System.Windows.Forms.GroupBox gb_SoruGuncellemePaneli;
        private System.Windows.Forms.TextBox txt_dCevabi;
        private System.Windows.Forms.TextBox txt_cCevabi;
        private System.Windows.Forms.TextBox txt_bCevabi;
        private System.Windows.Forms.TextBox txt_aCevabi;
        private System.Windows.Forms.TextBox txt_Soru;
        private System.Windows.Forms.Button bt_SoruGuncelle;
        private System.Windows.Forms.Button bt_SoruSil;
        private System.Windows.Forms.Button bt_SoruEkle;
        private System.Windows.Forms.Button bt_SoruListesiniGuncelle;
        private System.Windows.Forms.Label lb_Sorular;
        private System.Windows.Forms.Label lb_Cevaplar;
        private System.Windows.Forms.ListView lv_Sorular;
        private System.Windows.Forms.ListView lv_Cevaplar;
        private System.Windows.Forms.ColumnHeader soruNum;
        private System.Windows.Forms.ColumnHeader soru;
        private System.Windows.Forms.ColumnHeader sorNum;
        private System.Windows.Forms.ColumnHeader aCevabi;
        private System.Windows.Forms.ColumnHeader bCevabi;
        private System.Windows.Forms.ColumnHeader cCevabi;
        private System.Windows.Forms.ColumnHeader dCevabi;
    }
}