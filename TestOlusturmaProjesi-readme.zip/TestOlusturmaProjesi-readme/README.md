# Test Oluşturma Projesi
- Projenin Adı: Test Oluştur
- Projemizin amacı: Test çözmek isteyen herhangi bir kimsenin internette zaten halihazırda bulunan sorular arasından kendine soruları rastgele seçilerek bir test oluşturup çözmesi.
- Ekip Üyeleri: Eren YILMAZ 210702500 - Burak Alp AKDERE 200702502
# Çalışma Mantığı
- Çalışma mantığı olarak ilk önce bir doğrulama ekranı geliyor karşınıza, malum önüne gelen herkes soru ekleyemesin sadece yetkililer ekleyebilsin diye bir admin paneli ve misafir paneli bulunuyor.
- Eğer misafir olarak giriş yaparsanız karşınıza direkt 10 sorudan oluşan bir test ve şıkları geliyor.
- Eğer admin olarak giriş yapabilirseniz ise veritabanına soru ekleme, soru silme ve içerideki soruları güncellemenizi sağlayan bir panel ile karşı karşıya geliyorsunuz.
